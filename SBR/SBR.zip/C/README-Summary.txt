Version 2.1.0 of the C APIs (Last updated: 16 October 2015)
================================

There are two ways to get access to the C APIs.

Pre-built Binaries
==================

You can obtain prebuilt binaries for the libraries and sample applications for a selection of platforms. 

If debug versions are required, they will need to be built from source. The build scripts include an option for this.


Building From Source
====================

1. Read the instructions on establishing the build environment contained in the README.TXT file located in the _misc 
   directory of the abrbase source package. This includes details of the build tools required (Doxygen, CMake, CPack, etc).

2. Unpack the abrbase source package as well as any of the other source packages required into the directory structure 
   documented in the readme.

3. Invoke the build process.

Packages
========
The packages are seperated by API: BASE, AKM, STM, CSR.

They contain the libraries and sample programs and include the source as well as prebuilt binaries.

The BASE package is a common dpendency. The libraries are otherwise independent of each other. 
The sample programs do have dependecies on the various libraries, as appropriate.

Not all the APIs have updated versions numbers. The number above relates to the highest number of the sub packages.

Windows Dependencies
====================
The additional packages Windows-Dependencies.zip is supplied for the Windows platform as a courtesy,
as it can be difficult to find a consistent set of prebuilt libraries for Windows (same threading, bitsize, etc).
Such inconsistencies lead to segmentation and other crashes.
Please refer to the relevant Third Party licenses.
